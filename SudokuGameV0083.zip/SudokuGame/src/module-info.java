/**
 * 
 */
/**
 * @author zwmsc
 *
 */
module sSudokuGame {
	requires java.desktop;
}