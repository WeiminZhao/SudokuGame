package main.sudoku;

import java.util.ArrayList;

public class Numbers {

	ArrayList<Integer> N;
	
	public Numbers() {
		N=new ArrayList<Integer>();
		for(int i=1;i<=9;i++)
		{
			N.add(i);
		}
	}
	
	
	
}
